const authJwt = require("./authorize");
const verifySignUp = require("./verifySignUp");

module.exports = {
  authJwt,
  verifySignUp
};