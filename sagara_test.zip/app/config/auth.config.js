module.exports = {
    secret: "secret-key"
  };